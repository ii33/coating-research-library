"""Bounded plateau-trigger experiment; no production source or scoring edits."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
from time import monotonic

import numpy as np
import scipy.optimize

from coat_sim.core.film_auto_synthesis import _proxy, _synthesis_working_set_estimate_bytes
from coat_sim.core.film_optimization_structure import _PreparedStructureEvaluator, _StructureCancelled
from coat_sim.core.film_synthesis_io import film_synthesis_request_from_payload
from coat_sim.core.film_synthesis_refinement import (
    refine_synthesis_explorer, weighted_sse_loss_gradient, SynthesisStageBudget,
    SynthesisResourceGuard)

import record_helpers as helper

HERE = Path(__file__).resolve().parent
WARM_CALLS, WARM_SECONDS, MIN_WARM_CALLS = 256, 600., 64
WINDOW, RELATIVE_SSE, ABS_MAX_IMPROVEMENT = 16, .001, .0001
ARM_EQUIVALENT_CALLS, ARM_SECONDS, CHILD_CALLS = 64, 180., 8
SOURCE_SHA = '7e43ebf845d82e50e7bf38bbcc227671fbc68b04'


def write(name, value):
    path = HERE / name
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def array_bytes(value):
    """Count unique ndarray payloads only, a disclosed retained-cache proxy."""
    seen = set()

    def visit(item):
        identity = id(item)
        if identity in seen:
            return 0
        seen.add(identity)
        if isinstance(item, np.ndarray):
            return item.nbytes
        if isinstance(item, dict):
            return sum(visit(x) for x in item.values())
        if isinstance(item, (list, tuple)):
            return sum(visit(x) for x in item)
        return 0

    return visit(value)


def plateau_windows(records):
    """Two adjacent windows of16 accepted transitions, never trial samples."""
    if len(records) < 2 * WINDOW + 1:
        return None
    tail = records[-(2 * WINDOW + 1):]
    windows = []
    for start in (0, WINDOW):
        block = tail[start:start + WINDOW + 1]
        initial = block[0]['weighted_sse']
        best = min(x['weighted_sse'] for x in block)
        relative = (initial - best) / max(abs(initial), np.finfo(float).tiny)
        strict_initial = block[0]['best_original_max_error_so_far']
        strict_final = block[-1]['best_original_max_error_so_far']
        windows.append(dict(first_accepted=block[0]['accepted_iteration'],
            last_accepted=block[-1]['accepted_iteration'],
            initial_sse=initial, best_sse=best, relative_sse_improvement=relative,
            best_original_max_error_improvement=strict_initial - strict_final,
            passes=bool(relative <= RELATIVE_SSE and
                        strict_initial - strict_final <= ABS_MAX_IMPROVEMENT)))
    return windows


def projected_gradient(request, value):
    rows = value['design']['front_layers']
    loss, g_nm = weighted_sse_loss_gradient(request, value, tuple(r['id'] for r in rows))
    x = np.array([r['thickness']['value'] / 100. for r in rows])
    gradient = np.asarray(g_nm) * 100.
    lower = (request.minimum_nonzero_thickness_nm or 0.) / 100.
    upper = np.inf if request.max_layer_thickness_nm is None else request.max_layer_thickness_nm / 100.
    residual = x - np.clip(x - gradient, lower, upper)
    return dict(weighted_sse=loss, coordinate='x_i=d_i/100nm',
        definition='r=x-project_[lower/100,upper/100](x-gradient_x F), exact bounds, no epsilon',
        gradient_x_inf=float(np.linalg.norm(gradient, ord=np.inf)),
        projected_residual_inf=float(np.linalg.norm(residual, ord=np.inf)),
        exact_lower_bound_variables=int(np.count_nonzero(x == lower)),
        exact_upper_bound_variables=0 if np.isinf(upper) else int(np.count_nonzero(x == upper)),
        purpose='Diagnostic only; the operational plateau is not a local-optimum certificate.')


class Broker:
    def __init__(self, request, points, phase, *, warm=False, checkpoint=None):
        self.request, self.points = request, points
        self.prepared = _PreparedStructureEvaluator(_proxy(request))
        self.checkpoint = checkpoint
        self.checkpoint_record = None
        self.checkpoint_retained_array_bytes = array_bytes(checkpoint) if checkpoint is not None else 0
        self.warm_summary = None
        self.warm_accepted = []
        self.warm_global_iterations = 0
        self.begin_phase(phase, warm=warm)

    def begin_phase(self, phase, *, warm):
        self.phase, self.is_warm = phase, warm
        self.started = monotonic()
        self.deadline = self.started + (WARM_SECONDS if warm else ARM_SECONDS)
        self.call_cap = WARM_CALLS if warm else None
        self.work_cap = None if warm else ARM_EQUIVALENT_CALLS * self.points * len(self.checkpoint['design']['front_layers'])
        self.calls = self.completed = self.work = self.accepted_count = 0
        self.objective_calls = self.objective_cache_hits = self.objective_aborted = 0
        self.objective_feasibility_returns = 0
        self.stage_end = float('inf')
        self.stage = phase
        self.stop_reason = None
        self.trace = []
        self.accepted_records = []
        self.last_accepted = self.checkpoint
        self.champion = helper.compact(self.checkpoint) if self.checkpoint is not None else None
        self.best_sse = self.champion
        self.journal = HERE / (phase + '-calls.jsonl')
        self.journal.write_text('')
        self.accepted_journal = HERE / (phase + '-accepted.jsonl')
        self.accepted_journal.write_text('')

    def is_set(self):
        return monotonic() >= self.deadline

    def check(self):
        if self.is_set():
            self.stop_reason = 'wall_limit'
            raise SynthesisStageBudget('wall_limit')
        if self.call_cap is not None and self.calls >= self.call_cap:
            self.stop_reason = 'call_limit'
            raise SynthesisStageBudget('call_limit')
        if self.work_cap is not None and self.work >= self.work_cap:
            self.stop_reason = 'point_layer_work_limit'
            raise SynthesisStageBudget('point_layer_work_limit')
        if self.calls >= self.stage_end:
            raise SynthesisStageBudget('child_quantum')

    def evaluate(self, design, *, jacobian=False, zero_ids=()):
        self.check()
        assert jacobian, 'All evaluations in this protocol include analytic Jacobians.'
        layers = len(design['front_layers'])
        work = layers * self.points
        if self.work_cap is not None and self.work + work > self.work_cap:
            self.stop_reason = 'next_full_call_exceeds_point_layer_work_limit'
            raise SynthesisStageBudget(self.stop_reason)
        estimate = _synthesis_working_set_estimate_bytes(self.request, layers, jacobian=True)
        # The production proxy already contains its128MiB fixed baseline.
        # Add retained checkpoint arrays and128MiB for Python response/metric
        # records rather than silently treating their array bytes as full RSS.
        combined = estimate + self.checkpoint_retained_array_bytes + 128 * 1024 * 1024
        if combined > self.request.max_working_set_bytes:
            self.stop_reason = 'combined_resource_guard'
            raise SynthesisResourceGuard(self.stop_reason)
        self.calls += 1
        self.work += work
        before = monotonic()
        try:
            value = self.prepared.evaluate(design,
                variable_ids=tuple(r['id'] for r in design['front_layers']),
                with_jacobian=True, zero_thickness_layer_ids=zero_ids,
                derived_validation_grid=False, cancel_event=self)
        except _StructureCancelled:
            self.stop_reason = 'wall_limit_during_physics'
            record = dict(call=self.calls, stage=self.stage, complete=False,
                elapsed_seconds=monotonic() - self.started, point_layers=work)
            self.record(record)
            raise
        self.completed += 1
        metrics = helper.describe(value)
        record = dict(call=self.calls, stage=self.stage, complete=True, jacobian=True,
            physical_seconds=monotonic() - before, elapsed_seconds=monotonic() - self.started,
            point_layers=work, cumulative_F_point_layers=0,
            cumulative_FJ_point_layers=self.work, working_set_proxy_bytes=combined,
            metrics=metrics)
        self.record(record)
        if self.champion is None or helper.rank(value) < helper.rank(self.champion):
            self.champion = helper.compact(value)
        if self.best_sse is None or metrics['weighted_sse'] < helper.describe(self.best_sse)['weighted_sse']:
            self.best_sse = helper.compact(value)
        if self.calls % 16 == 0:
            print(json.dumps(dict(phase=self.phase, calls=self.calls,
                elapsed_seconds=monotonic() - self.started,
                strict_max_error=helper.describe(self.champion)['max_error'],
                best_sse=helper.describe(self.best_sse)['weighted_sse'])), flush=True)
        return value

    def record(self, record):
        self.trace.append(record)
        with self.journal.open('a') as stream:
            stream.write(json.dumps(record, allow_nan=False) + '\n')

    def progress(self, stage, value, details):
        if stage != 'hybrid_sse_accepted_iterate':
            return
        self.last_accepted = value
        self.accepted_count += 1
        measured = helper.describe(value)
        record = dict(accepted_iteration=self.accepted_count, global_iteration=details['iterations'],
            physical_calls=self.calls, elapsed_seconds=monotonic() - self.started,
            weighted_sse=measured['weighted_sse'], original_max_error=measured['max_error'],
            best_original_max_error_so_far=helper.describe(self.champion)['max_error'],
            physical_hash=measured['physical_hash'])
        self.accepted_records.append(record)
        with self.accepted_journal.open('a') as stream:
            stream.write(json.dumps(record, allow_nan=False) + '\n')
        if not self.is_warm:
            return
        windows = plateau_windows(self.accepted_records)
        if self.calls < MIN_WARM_CALLS or windows is None or not all(w['passes'] for w in windows):
            return
        diagnostic = projected_gradient(self.request, value)
        self.check()  # Never admit continuation after warm-up expires.
        self.checkpoint = value  # Immutable physical value retained, not optimizer state replacement.
        self.checkpoint_retained_array_bytes = array_bytes(value)
        self.checkpoint_record = dict(metrics=measured, windows=windows,
            projected_gradient=diagnostic, physical_calls=self.calls,
            accepted_iterates=self.accepted_count,
            elapsed_seconds=monotonic() - self.started)
        self.warm_summary = self.summary()
        self.warm_global_iterations = details['iterations']
        self.warm_accepted = list(self.accepted_records)
        write('warmup-summary.json', self.warm_summary)
        write('checkpoint.json', dict(design=deepcopy(value['design']), **self.checkpoint_record))
        print(json.dumps(dict(checkpoint=True, **self.checkpoint_record)), flush=True)
        # Return normally to exactly the live solver callback. No SciPy restart,
        # thickness cleanup or objective replacement occurs in arm A.
        self.begin_phase('arm-a-uninterrupted', warm=False)

    def refine(self, initial, *, quota=None, label=None):
        if label is not None:
            self.stage = label
        self.stage_end = float('inf') if quota is None else self.calls + quota
        self.last_accepted = initial
        before = self.calls
        before_phase = self.phase
        original_minimize = scipy.optimize.minimize

        def instrumented_minimize(fun, x0, *args, **kwargs):
            def counted_fun(x):
                self.objective_calls += 1
                calls_before = self.calls
                try:
                    result = fun(x)
                except (SynthesisStageBudget, SynthesisResourceGuard, _StructureCancelled):
                    self.objective_aborted += 1
                    raise
                if self.calls == calls_before:
                    feasible = all((lo is None or v >= lo) and (hi is None or v <= hi)
                        for v, (lo, hi) in zip(x, kwargs['bounds'], strict=True))
                    if feasible:
                        self.objective_cache_hits += 1
                    else:
                        self.objective_feasibility_returns += 1
                return result
            return original_minimize(counted_fun, x0, *args, **kwargs)

        scipy.optimize.minimize = instrumented_minimize
        try:
            endpoint, details = refine_synthesis_explorer(self.request, initial,
                evaluate=self.evaluate, archive=lambda *a, **k: None,
                cancel_check=self.check, progress=self.progress, max_iterations=10000)
        except _StructureCancelled:
            endpoint, details = self.last_accepted, dict(termination='wall_limit_during_physics')
        finally:
            scipy.optimize.minimize = original_minimize
        self.stage_end = float('inf')
        calls_used = self.calls - before
        if self.phase != before_phase:
            calls_used += self.warm_summary['physical_FJ_calls']
        return endpoint, dict(details, broker_calls_used=calls_used,
            solver_spans_warmup_and_arm_a=self.phase != before_phase,
            endpoint=helper.describe(endpoint))

    def summary(self):
        return dict(phase=self.phase, physical_F_calls=0, physical_FJ_calls=self.calls,
            completed_calls=self.completed, accepted_callback_iterates=self.accepted_count,
            scipy_objective_calls=self.objective_calls, objective_cache_hits=self.objective_cache_hits,
            objective_feasibility_returns=self.objective_feasibility_returns,
            objective_aborted_calls=self.objective_aborted,
            F_point_layers=0, FJ_point_layers=self.work,
            call_cap=self.call_cap, work_cap=self.work_cap,
            wall_cap_seconds=WARM_SECONDS if self.is_warm else ARM_SECONDS,
            elapsed_seconds=monotonic() - self.started, stop_reason=self.stop_reason,
            strict_champion=None if self.champion is None else helper.describe(self.champion),
            best_explored_sse=None if self.best_sse is None else helper.describe(self.best_sse),
            last_plateau_windows=plateau_windows(self.accepted_records))

    def save(self, endpoint, details):
        summary = dict(**self.summary(), solver=details,
            actual_endpoint=helper.describe(endpoint), independent_audit=False)
        write(self.phase + '-summary.json', summary)
        for role, value in [('champion', self.champion), ('best-explored', self.best_sse), ('endpoint', endpoint)]:
            write(self.phase + '-' + role + '.json',
                dict(design=value['design'], metrics=helper.describe(value)))
        return summary


def main():
    payload = json.loads((HERE / 'inputs/request-v3.json').read_text())
    _, request, _ = film_synthesis_request_from_payload(payload)
    helper.REQUEST = request
    points = sum(o.wavelength_samples * len(o.angles_deg) for o in request.objectives)
    original = json.loads((HERE / 'inputs/warm-start-a57.json').read_text())['design']
    protocol = dict(source_sha=SOURCE_SHA, warm_start='Prior negative pilot arm A57 strict champion, not a fresh seed and not selected in this new run.',
        warm_calls=WARM_CALLS, warm_seconds=WARM_SECONDS, min_warm_calls=MIN_WARM_CALLS,
        plateau_definition='Two adjacent16-accepted-transition windows, each relative best SSE gain<=.001 and best original max-violation gain<=.0001; operational, not stationarity proof.',
        arm_equivalent_FJ_calls=ARM_EQUIVALENT_CALLS, arm_seconds=ARM_SECONDS,
        arm_work_definition='64*checkpoint raw rows*10252 point-layers; every admitted call FJ, F=0; partial full calls are not dispatched.',
        child_calls_inclusive_first_FJ=CHILD_CALLS, children=4,
        A='Continue live optimizer unchanged from checkpoint callback.',
        B='Restart same topology from exact checkpoint with cached full Jacobian; no uncharged refresh.',
        C='Four maximin-diverse nonzero physical deletions,8FJ calls each including initial, then chosen refined SSE endpoint; selected compact endpoint refresh charged.',
        no_plateau='Do not launch any arms; report bounded inconclusive warm-up.',
        unchanged_targets=True, unchanged_k0_hypothesis=True, unchanged_scorer=True,
        grid_points=points, independent_audit=False, repeats=1,
        input_hashes={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted((HERE / 'inputs').iterdir()) if p.is_file()})
    write('protocol.json', protocol)
    print(json.dumps(dict(starting='bounded plateau warm-up', protocol=protocol)), flush=True)
    warm = Broker(request, points, 'warmup', warm=True)
    initial = warm.evaluate(original, jacobian=True)
    endpoint, details = warm.refine(initial)
    if warm.checkpoint is None:
        summary = warm.save(endpoint, details)
        write('result.json', dict(outcome='inconclusive_no_operational_plateau_within_bound',
            warmup=summary, final_projected_gradient=projected_gradient(request, endpoint),
            arms=[], no_independent_audit=True))
        print(json.dumps(dict(done=True, arms_launched=0, outcome='no_plateau', warmup=summary)), flush=True)
        return
    a = warm.save(endpoint, details)
    checkpoint = warm.checkpoint
    b_broker = Broker(request, points, 'arm-b-restart-only', checkpoint=checkpoint)
    b_endpoint, b_details = b_broker.refine(checkpoint)
    b = b_broker.save(b_endpoint, b_details)
    children = helper.deletion_children(checkpoint['design'])
    write('deletion-children.json', children)
    c_broker = Broker(request, points, 'arm-c-deletion-competition', checkpoint=checkpoint)
    child_endpoints, child_details = [], []
    chosen = None
    c_endpoint = checkpoint
    try:
        for child in children:
            c_broker.stage = child['child_id'] + '_first_FJ'
            zero_ids = tuple(r['id'] for r in child['design']['front_layers'] if r['thickness']['value'] == 0.)
            raw = c_broker.evaluate(child['design'], jacobian=True, zero_ids=zero_ids)
            c_endpoint, d = c_broker.refine(raw, quota=CHILD_CALLS - 1,
                                           label=child['child_id'] + '_initial_refit')
            child_endpoints.append(helper.compact(c_endpoint))
            child_details.append(dict(child_id=child['child_id'], raw=helper.describe(raw), **d))
            del raw
        chosen = min(range(len(child_endpoints)), key=lambda i: (
            helper.describe(child_endpoints[i])['weighted_sse'], children[i]['child_id']))
        c_endpoint, c_details = c_broker.refine(child_endpoints[chosen], label='chosen_child_remaining_refit')
    except (SynthesisStageBudget, SynthesisResourceGuard, _StructureCancelled) as error:
        c_endpoint = c_broker.last_accepted or c_endpoint
        c_details = dict(termination=type(error).__name__)
    c = c_broker.save(c_endpoint, dict(**c_details, children=child_details, chosen_child=chosen))
    write('result.json', dict(outcome='three_arm_plateau_branch_test', warmup=warm.warm_summary,
        checkpoint=warm.checkpoint_record, arms=[a, b, c], no_independent_audit=True))
    print(json.dumps(dict(done=True, arms_launched=3,
        champions=[r['strict_champion'] for r in (a, b, c)])), flush=True)


if __name__ == '__main__':
    main()

"""Read recorded data only. No optical evaluations or optimization runs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform

import numpy
import scipy

from coat_sim.core.film_synthesis_batch_needle import cleanup_batch_needle_design
from coat_sim.core.film_synthesis_io import film_synthesis_request_from_payload
from run_plateau_pilot import MIN_WARM_CALLS, plateau_windows

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE / name).read_text())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    result = read('result.json')
    protocol = read('protocol.json')
    _, request, _ = film_synthesis_request_from_payload(read('inputs/request-v3.json'))
    accepted = [json.loads(r) for r in (HERE / 'warmup-accepted.jsonl').read_text().splitlines()]
    calls = [json.loads(r) for r in (HERE / 'warmup-calls.jsonl').read_text().splitlines()]
    checks = []
    for i in range(33, len(accepted) + 1):
        if accepted[i - 1]['physical_calls'] >= MIN_WARM_CALLS:
            windows = plateau_windows(accepted[:i])
            checks.append(dict(accepted_iterate=i, physical_call=accepted[i - 1]['physical_calls'],
                windows=windows, passes=all(w['passes'] for w in windows)))
    summary = result['warmup']
    initial = calls[0]['metrics']
    assert summary['physical_FJ_calls'] == len(calls)
    assert summary['completed_calls'] == sum(c['complete'] for c in calls)
    assert summary['FJ_point_layers'] == sum(c['point_layers'] for c in calls)
    terminal_check = None
    if not result['arms'] and summary['solver']['iterations'] == len(accepted) + 1:
        terminal = summary['actual_endpoint']
        terminal_call = next(c for c in reversed(calls)
                             if c['complete'] and c['metrics']['physical_hash'] == terminal['physical_hash'])
        final_record = dict(accepted_iteration=summary['solver']['iterations'],
            weighted_sse=terminal['weighted_sse'],
            best_original_max_error_so_far=summary['strict_champion']['max_error'])
        terminal_check = dict(scope='Post-run arithmetic on the committed endpoint omitted from the final progress callback; no optics or branch admission.',
            physical_call=terminal_call['call'],
            accepted_iteration=final_record['accepted_iteration'],
            windows=plateau_windows(accepted + [final_record]))
    counts = {}
    if not result['arms']:
        for role in ('champion', 'best-explored', 'endpoint'):
            stored = read('warmup-' + role + '.json')
            cleaned = cleanup_batch_needle_design(stored['design'], request.frozen_material_snapshot)
            assert cleaned.algebraically_equivalent and not cleaned.requires_full_reevaluation
            counts[role] = dict(raw_layers=len(stored['design']['front_layers']),
                physical_layers=len(cleaned.design['front_layers']),
                removed_exact_zero_ids=list(cleaned.removed_exact_zero_ids),
                merged_ids=dict(cleaned.merged_ids))
    compact = dict(outcome=result['outcome'], source_sha=protocol['source_sha'],
        warm_start=initial, warmup=summary, arm_count=len(result['arms']),
        admitted_plateau_checks=len(checks), passing_admitted_checks=sum(c['passes'] for c in checks),
        final_two_windows=checks[-1]['windows'] if checks else None,
        smallest_observed_worst_window_relative_SSE_gain=min(
            max(w['relative_sse_improvement'] for w in c['windows']) for c in checks) if checks else None,
        final_projected_gradient=result.get('final_projected_gradient'),
        terminal_boundary_check=terminal_check,
        layer_cleanup=counts, independent_audit=False,
        environment=dict(python=platform.python_version(), numpy=numpy.__version__, scipy=scipy.__version__))
    write('compact-result.json', compact)
    write('plateau-checks.json', checks)
    if result['arms']:
        print('Three-arm result recorded; explicit arm-prefix analysis is required before a report.')
        return
    assert not any(c['passes'] for c in checks)
    champion = summary['strict_champion']
    endpoint = summary['actual_endpoint']
    best_sse = summary['best_explored_sse']
    windows = checks[-1]['windows']
    band_rows = '\n'.join('| ' + str(i + 1) + ' | ' + b['metric'] + ', ' +
        '–'.join(f'{n:g}' for n in b['wavelength_nm']) + ' | ' +
        ' | '.join(f'{m["bands"][i]["sampled_min"]:.9f} / {m["bands"][i]["angle_mean_min"]:.9f}'
                   for m in (initial, champion, endpoint)) + ' |'
        for i, b in enumerate(initial['bands']))
    def row(name, metrics, count):
        return f'| {name} | {count} | {metrics["total_thickness_nm"]:.6f} | {metrics["max_error"]:.9f} | {metrics["weighted_sse"]:.9g} | {metrics["nominal_pass"]} |'
    metric_rows = '\n'.join([
        row('Saved A57 starting design', initial, '57 / 57'),
        row('Warm-up strict champion', champion, f'{counts["champion"]["raw_layers"]} / {counts["champion"]["physical_layers"]}'),
        row('Best explored SSE', best_sse, f'{counts["best-explored"]["raw_layers"]} / {counts["best-explored"]["physical_layers"]}'),
        row('Actual accepted endpoint', endpoint, f'{counts["endpoint"]["raw_layers"]} / {counts["endpoint"]["physical_layers"]}')])
    window_rows = '\n'.join(f'| {w["first_accepted"]}–{w["last_accepted"]} | {w["relative_sse_improvement"]:.9g} | {w["best_original_max_error_improvement"]:.9g} | {w["passes"]} |' for w in windows)
    text = f'''# Plateau qualification pilot: bounded inconclusive result

Date: 2026-10-24. Source SHA: `{protocol['source_sha']}`.

## Finding

No operational plateau was admitted within the predeclared warm-up bound. **The three comparison arms were not launched.** This does not establish a local minimum or show that deletion lookahead succeeds or fails after a plateau. It records continued local progress on one difficult case while declining to run an inapplicable escape experiment.

The warm-up used {summary['physical_FJ_calls']} admitted full-grid FJ calls, {summary['completed_calls']} completed calls, {summary['elapsed_seconds']:.3f} seconds, and {summary['FJ_point_layers']:,} FJ point-layers. F calls: 0. Stop: `{summary['stop_reason']}`. The ceiling was 256 FJ or 600 s, whichever first, with no extension.

## Purpose and frozen protocol

The falsifiable conditional hypothesis was that, **after a measured plateau**, a deterministic deletion-child/refinement competition improves original spectral constraints more efficiently than both uninterrupted local continuation and a restart-only control. Without the condition, no three-arm conclusion is available.

The seed is the prior negative pilot's saved A57 strict champion, not a fresh seed, a recovered historical design, or a seed selected during this run. Its exact bytes are frozen in `inputs/warm-start-a57.json`. Both mean and pointwise strict original goals remain enabled: R > 0.97 at 580–920 nm; R > 0.99 at 1039–1089 nm; T > 0.98 at 3650–5000 and 7650–10550 nm. Unpolarized angles 40–50 degrees at 1-degree steps; maximum wavelength step 5 nm, 10,252 wavelength-angle pairs. No goals, margins, constraints, scorer, or production source changed.

Materials remain the explicitly derived k=0 mathematical ZnS-substrate/ZnS/YbF3 model from the first pilot, with original n dispersion and source grids unchanged and new derived material IDs. This is not a measured engineering lossless-material claim. `inputs/derived-k0-pilot-manifest.json` preserves source/derived provenance. No independent denser/extremum audit was run; all metrics are screening-grid results.

Operational plateau required at least 64 FJ calls and two consecutive, non-overlapping windows of 16 accepted-iterate transitions each. In **each** window: relative best SSE improvement <=0.001 (0.1%), and strict-best original maximum-violation improvement <=0.0001 absolute. This is a disclosed project research criterion, not a convergence or local-optimum theorem. The exact comparisons use no epsilon relaxation.

Had it triggered, A would retain the same live L-BFGS-B invocation via normal callback return; B would restart the identical raw topology from the same complete cached checkpoint; C would give four deterministic diverse positive-row deletions 8 FJ calls each, then continue the best refined child, charging its refresh. Every arm would have 64 times checkpoint-row-count times10,252 FJ point-layers and 180 s; no new F-only calls. This all-FJ policy differs from the first pilot and is declared before execution. A/B would preserve raw topology to keep the optimizer-history control; C would clean exact zeros/equal optical neighbors after row deletion. These planned arms are **untested here**.

## Plateau and convergence evidence

Accepted progress callbacks: {summary['accepted_callback_iterates']}; solver-committed accepted iterations: {summary['solver']['iterations']}; SciPy objective invocations: {summary['scipy_objective_calls']}; objective cache hits: {summary['objective_cache_hits']}; aborted objective invocations: {summary['objective_aborted_calls']}. Physical and objective calls are not interchangeable. A complete cached initial Jacobian avoids an uncharged refresh; the initial warm-up FJ is counted.

There were {len(checks)} eligible admitted plateau checks and zero passes. The last observed windows were:

| Accepted-iterate range | Relative best SSE gain | Strict-best max-violation gain | Meets both thresholds |
|---|---:|---:|---|
{window_rows}

The smallest observed maximum relative SSE gain across any pair of eligible windows was {compact['smallest_observed_worst_window_relative_SSE_gain']:.9g}, compared with the required 0.001. All windows are preserved in `plateau-checks.json`; these are not thresholds retuned after seeing results.

The final projected-gradient diagnostic is r = x - project_bounds(x - gradient_x F), with x_i = d_i /100 nm, lower and upper bounds transformed identically, exact bound comparisons and no epsilon. Its infinity norm is {result['final_projected_gradient']['projected_residual_inf']:.9g}; raw coordinate-gradient infinity norm is {result['final_projected_gradient']['gradient_x_inf']:.9g}. It is a diagnostic for the original canonical SSE, not a certificate that all nominal constraints pass or that a global/local optimum has been found.

The production callback commits an accepted iterate before checking the budget, then emits progress. Thus a plateau first reached exactly at the terminal admission cannot be admitted for branching. Callback counts and the separately returned actual endpoint are both retained; do not interpret a missing final callback as an unevaluated endpoint.

Post-run recorded-data arithmetic also included the final committed endpoint at call {terminal_check['physical_call'] if terminal_check else 'not applicable'} / accepted iteration {terminal_check['accepted_iteration'] if terminal_check else 'not applicable'}. Its two windows pass both thresholds: {all(w['passes'] for w in terminal_check['windows']) if terminal_check else 'not applicable'}. This boundary check launches no arms and dispatches no optics; its exact values are in `compact-result.json`.

## Optical metrics and physical counts

Max violation is dimensionless; here 0.01 corresponds to a one-percentage-point deficit. SSE is the unchanged canonical equal-window/user-weighted guide. Strict champion, best explored SSE, and actual optimizer endpoint remain distinct roles.

| Candidate | Raw / exact-cleaned physical layers | Total nm | Original max violation | Weighted SSE | Original-grid nominal pass |
|---|---:|---:|---:|---:|---|
{metric_rows}

Each band cell below is sampled minimum / minimum over angle-specific complete-band wavelength means. Values are fractions, not percentages.

| Band | Metric, wavelength nm | Starting design | Strict champion | Actual endpoint |
|---|---|---|---|---|
{band_rows}

Layer cleanup is algebraic bookkeeping only: exact-zero removal and equal material/optical-set neighbor merge, no positive near-zero deletion or extra physics. The raw optimized variables are not silently changed. This is spectral refinement, not the separate feasible total-thickness-reduction operator.

## Limits and next hypothesis

One deliberately warm-started case, one serial run, both criteria enabled, synthetic k=0 materials and a coarse screening grid provide no cross-family, switch-mode, statistical-repeat, or dense-audit generalization. Work is a point-layer proxy, not FLOPs; memory enforcement is a declared production-workspace plus retained-checkpoint-array plus 128 MiB record allowance, not measured RSS. The frozen cap is 512 MiB; no low layer-count cap, GPU or user computer was used.

The supported lesson is narrow: this checkpoint still allowed substantial ordinary local descent within the bound, so a short previous budget was not evidence of being trapped. A possible next isolated hypothesis is whether progress-adaptive longer local service and retained optimizer history outperform repeated short restarts at equal work. That comparison has **not** been run here. Do not extend this same run until a plateau appears or report an escape result from the missing arms.

## Reproduction and versioned data

`protocol.json` was written before the first physical dispatch and records constants and exact input hashes. `run_plateau_pilot.py` is the executed experimental wrapper; it calls the unchanged production evaluator/refiner. `record_helpers.py` derives from the prior record/selection helpers, excluding zero-row and physically unchanged deletion proposals. `warmup-calls.jsonl` and `warmup-accepted.jsonl` are distinct physical-call and accepted-iterate histories. `warmup-summary.json`, saved designs, `result.json`, and `compact-result.json` preserve outcomes. `summarize_plateau.py` performs only recorded-data arithmetic and algebraic count checks.

Numerical environment: Python {platform.python_version()}, NumPy {numpy.__version__}, SciPy {scipy.__version__}; numerical thread environment variables were all 1. Use a separate copied directory with its relative `inputs/`, the source SHA above on PYTHONPATH, and recorded dependencies. The harness overwrites outputs. `artifact-manifest.json` supplies hashes. No production files or remote software releases are changed by this experiment.
'''
    (HERE / 'pilot-report.md').write_text(text)
    write('artifact-manifest.json', dict(source_sha=protocol['source_sha'],
        command='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONPATH=<source-checkout-at-recorded-sha> <python-with-recorded-dependencies> run_plateau_pilot.py',
        files={str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
               and p.name != 'artifact-manifest.json'}))
    print(json.dumps(dict(outcome=result['outcome'], admitted_checks=len(checks),
        strict_max_error=champion['max_error'], best_explored_sse=best_sse['weighted_sse'],
        final_windows=windows), indent=2))


if __name__ == '__main__':
    main()

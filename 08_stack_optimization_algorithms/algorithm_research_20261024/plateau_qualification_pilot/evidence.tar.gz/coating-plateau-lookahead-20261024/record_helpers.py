"""Copied record/selection helpers from the prior pilot, without executing it.

Deletion proposals exclude exact-zero rows and physically unchanged cleanup,
so this experiment cannot claim zero-row bookkeeping as a topology escape.
"""
from copy import deepcopy
import numpy as np
from coat_sim.core.film_synthesis_archive import physical_design_hash
from coat_sim.core.film_synthesis_batch_needle import cleanup_batch_needle_design

REQUEST = None

def describe(value):
    if '_pilot_metrics' in value:
        return deepcopy(value['_pilot_metrics'])
    score, design = value['score'], value['design']
    bands = []
    for index, objective in enumerate(REQUEST.objectives):
        rows = [r for r in score['errors'] if r.objective_index == index]
        point = [r.actual for r in rows if r.reduction == 'pointwise']
        means = [r.actual for r in rows if r.reduction == 'mean']
        bands.append(dict(index=index, metric=objective.metric,
            wavelength_nm=[objective.wavelength_min_nm, objective.wavelength_max_nm],
            sampled_min=min(point) if point else None, sampled_max=max(point) if point else None,
            angle_mean_min=min(means) if means else None, angle_mean_max=max(means) if means else None,
            max_error=max(r.normalized_violation for r in rows),
            nominal_pass=all(r.actual > getattr(objective, r.reduction).lower_bound for r in rows)))
    return dict(physical_hash=physical_design_hash(design), layer_count=len(design['front_layers']),
        total_thickness_nm=sum(r['thickness']['value'] for r in design['front_layers']),
        max_error=float(score['max_error']), weighted_sse=float(score['weighted_rms_error'])**2,
        nominal_pass=bool(score['nominal_pass']), bands=bands)


def compact(value):
    return dict(design=deepcopy(value['design']),
        score={k: value['score'][k] for k in ('max_error', 'weighted_rms_error', 'nominal_pass')},
        _pilot_metrics=describe(value))


def rank(value):
    m = describe(value)
    if m['nominal_pass']:
        return (0, m['layer_count'], m['total_thickness_nm'], m['max_error'], m['weighted_sse'])
    return (1, m['max_error'], m['weighted_sse'], m['layer_count'], m['total_thickness_nm'])


def deletion_children(parent):
    rows = parent['front_layers']
    material_keys = sorted({(r['material_id'], r['optical_set_id']) for r in rows})
    ds = np.array([r['thickness']['value'] for r in rows])
    centers = (np.cumsum(ds)-ds/2)/sum(ds)
    log_ds = np.log(np.maximum(ds, np.finfo(float).tiny))
    span = float(np.max(log_ds)-np.min(log_ds))
    normalized = np.zeros(len(ds)) if span == 0. else (log_ds-min(log_ds))/span
    features = [np.array([float((r['material_id'], r['optical_set_id']) == key) for key in material_keys]
        + [float(normalized[i]), float(centers[i])]) for i, r in enumerate(rows)]
    chosen, identities, result = [], {physical_design_hash(cleanup_batch_needle_design(parent, REQUEST.frozen_material_snapshot).design)}, []
    while len(result) < 4:
        remaining = [i for i in range(len(rows)) if i not in chosen and ds[i] > 0.]
        if not remaining:
            raise ValueError('fewer than four distinct deletion children')
        def key(i):
            distance = min(float(np.linalg.norm(features[i]-features[j])) for j in chosen) if chosen else float(ds[i])
            return (-distance, rows[i]['id'], i)
        index = min(remaining, key=key)
        chosen.append(index)
        raw = deepcopy(parent)
        raw['front_layers'].pop(index)
        cleaned = cleanup_batch_needle_design(raw, REQUEST.frozen_material_snapshot)
        identity = physical_design_hash(cleaned.design)
        if identity in identities:
            continue
        identities.add(identity)
        result.append(dict(child_id=f'child-{len(result)}', removed_layer_id=rows[index]['id'],
            removed_material_id=rows[index]['material_id'], original_index=index,
            removed_thickness_nm=float(ds[index]), feature=features[index].tolist(),
            raw_layer_count=len(raw['front_layers']), physical_layer_count=len(cleaned.design['front_layers']),
            merged_ids=dict(cleaned.merged_ids), physical_hash=identity, design=cleaned.design))
        if len(result) == 4:
            break
    if len(result) != 4:
        raise ValueError('selection did not yield four unique children')
    return result



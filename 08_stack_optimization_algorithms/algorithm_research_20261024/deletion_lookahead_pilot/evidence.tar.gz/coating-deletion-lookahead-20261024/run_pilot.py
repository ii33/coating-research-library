"""Bounded experiment only: raw-selection versus independent deletion-child refits.

No production-search edits, scorer changes, goal relaxation or dense-audit claim.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
from time import monotonic

import numpy as np

from coat_sim.core.film_auto_synthesis import _proxy, _synthesis_working_set_estimate_bytes
from coat_sim.core.film_optimization_structure import _PreparedStructureEvaluator, _StructureCancelled
from coat_sim.core.film_synthesis_archive import physical_design_hash
from coat_sim.core.film_synthesis_batch_needle import cleanup_batch_needle_design
from coat_sim.core.film_synthesis_io import film_synthesis_request_from_payload, SCHEMA_VERSION
from coat_sim.core.film_synthesis_refinement import refine_synthesis_explorer, SynthesisStageBudget

HERE = Path(__file__).resolve().parent
INPUT = HERE / 'inputs'
WARM_CALLS, ARM_CALLS, CHILD_QUOTA, WALL_SECONDS = 24, 64, 8, 90.


def write(name, value):
    path = HERE / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
    temporary.replace(path)


def describe(value):
    if '_pilot_metrics' in value:
        return deepcopy(value['_pilot_metrics'])
    score, design = value['score'], value['design']
    bands = []
    for index, objective in enumerate(REQUEST.objectives):
        rows = [r for r in score['errors'] if r.objective_index == index]
        point = [r.actual for r in rows if r.reduction == 'pointwise']
        means = [r.actual for r in rows if r.reduction == 'mean']
        bands.append(dict(index=index, metric=objective.metric,
            wavelength_nm=[objective.wavelength_min_nm, objective.wavelength_max_nm],
            sampled_min=min(point) if point else None, sampled_max=max(point) if point else None,
            angle_mean_min=min(means) if means else None, angle_mean_max=max(means) if means else None,
            max_error=max(r.normalized_violation for r in rows),
            nominal_pass=all(r.actual > getattr(objective, r.reduction).lower_bound for r in rows)))
    return dict(physical_hash=physical_design_hash(design), layer_count=len(design['front_layers']),
        total_thickness_nm=sum(r['thickness']['value'] for r in design['front_layers']),
        max_error=float(score['max_error']), weighted_sse=float(score['weighted_rms_error'])**2,
        nominal_pass=bool(score['nominal_pass']), bands=bands)


def compact(value):
    return dict(design=deepcopy(value['design']),
        score={k: value['score'][k] for k in ('max_error', 'weighted_rms_error', 'nominal_pass')},
        _pilot_metrics=describe(value))


def rank(value):
    m = describe(value)
    if m['nominal_pass']:
        return (0, m['layer_count'], m['total_thickness_nm'], m['max_error'], m['weighted_sse'])
    return (1, m['max_error'], m['weighted_sse'], m['layer_count'], m['total_thickness_nm'])


class Broker:
    def __init__(self, name, cap):
        self.name, self.cap = name, cap
        self.started = monotonic()
        self.deadline = self.started + WALL_SECONDS
        self.calls = self.completed = self.forward_calls = self.jacobian_calls = 0
        self.forward_work = self.jacobian_work = 0
        self.stage_end = cap
        self.stage = 'parent'
        self.trace = []
        self.champion = self.best_sse = None
        self.accepted = None
        self.stop_reason = None
        self.prepared = _PreparedStructureEvaluator(_proxy(REQUEST))
        self.journal = HERE / (name + '-calls.jsonl')
        self.journal.write_text('')

    def is_set(self):
        return monotonic() >= self.deadline

    def check(self):
        if self.is_set():
            self.stop_reason = 'wall_limit'
            raise SynthesisStageBudget('wall_limit')
        if self.calls >= self.cap:
            self.stop_reason = 'call_limit'
            raise SynthesisStageBudget('call_limit')
        if self.calls >= self.stage_end:
            raise SynthesisStageBudget('child_quantum')

    def evaluate(self, design, *, jacobian=False, zero_ids=()):
        self.check()
        n = len(design['front_layers'])
        estimate = _synthesis_working_set_estimate_bytes(REQUEST, n, jacobian=jacobian)
        if estimate > REQUEST.max_working_set_bytes:
            self.stop_reason = 'resource_guard'
            raise SynthesisStageBudget('resource_guard')
        self.calls += 1
        if jacobian:
            self.jacobian_calls += 1
            self.jacobian_work += POINTS * n
        else:
            self.forward_calls += 1
            self.forward_work += POINTS * n
        before = monotonic()
        try:
            value = self.prepared.evaluate(design,
                variable_ids=tuple(r['id'] for r in design['front_layers']) if jacobian else (),
                with_jacobian=jacobian, zero_thickness_layer_ids=zero_ids,
                derived_validation_grid=False, cancel_event=self)
        except _StructureCancelled:
            self.stop_reason = 'wall_limit_during_physics'
            event = dict(call=self.calls, stage=self.stage, jacobian=jacobian, complete=False,
                elapsed_seconds=monotonic()-self.started, physical_seconds=monotonic()-before)
            self.trace.append(event)
            with self.journal.open('a') as stream:
                stream.write(json.dumps(event)+'\n')
            raise
        self.completed += 1
        measured = describe(value)
        event = dict(call=self.calls, stage=self.stage, jacobian=jacobian, complete=True,
            elapsed_seconds=monotonic()-self.started, physical_seconds=monotonic()-before,
            sampled_points=POINTS, point_layers=POINTS*n,
            cumulative_forward_point_layers=self.forward_work,
            cumulative_jacobian_point_layers=self.jacobian_work, metrics=measured)
        self.trace.append(event)
        with self.journal.open('a') as stream:
            stream.write(json.dumps(event, allow_nan=False)+'\n')
        if self.champion is None or rank(value) < rank(self.champion):
            self.champion = compact(value)
        if self.best_sse is None or measured['weighted_sse'] < describe(self.best_sse)['weighted_sse']:
            self.best_sse = compact(value)
        if self.calls % 8 == 0:
            print(json.dumps(dict(phase=self.name, calls=self.calls, elapsed=monotonic()-self.started,
                champion_max_error=describe(self.champion)['max_error'], best_sse=describe(self.best_sse)['weighted_sse'])), flush=True)
        return value

    def progress(self, stage, value, details):
        if stage == 'hybrid_sse_accepted_iterate':
            self.accepted = compact(value)

    def refine(self, initial, quota, label):
        self.stage = label
        self.stage_end = min(self.cap, self.calls + quota)
        self.accepted = compact(initial)
        before = self.calls
        try:
            endpoint, details = refine_synthesis_explorer(REQUEST, initial, evaluate=self.evaluate,
                archive=lambda *a, **k: None, cancel_check=self.check, progress=self.progress,
                max_iterations=1000)
        except _StructureCancelled:
            endpoint = self.accepted
            details = dict(termination='wall_limit_during_physics')
        details = dict(details, calls_used=self.calls-before, stage=label,
            endpoint=describe(endpoint), wall_seconds=monotonic()-self.started)
        self.stage_end = self.cap
        return compact(endpoint), details

    def summary(self):
        return dict(name=self.name, call_cap=self.cap, wall_cap_seconds=WALL_SECONDS,
            admitted_calls=self.calls, completed_calls=self.completed,
            forward_calls=self.forward_calls, jacobian_calls=self.jacobian_calls,
            forward_point_layers=self.forward_work, jacobian_point_layers=self.jacobian_work,
            work_scope='admitted full-grid proxy; incomplete physical calls explicitly marked; F and FJ not assumed equal cost',
            elapsed_seconds=monotonic()-self.started, stop_reason=self.stop_reason,
            strict_champion=describe(self.champion) if self.champion is not None else None,
            best_explored_sse=describe(self.best_sse) if self.best_sse is not None else None)


def deletion_children(parent):
    rows = parent['front_layers']
    material_keys = sorted({(r['material_id'], r['optical_set_id']) for r in rows})
    ds = np.array([r['thickness']['value'] for r in rows])
    centers = (np.cumsum(ds)-ds/2)/sum(ds)
    log_ds = np.log(np.maximum(ds, np.finfo(float).tiny))
    span = float(np.max(log_ds)-np.min(log_ds))
    normalized = np.zeros(len(ds)) if span == 0. else (log_ds-min(log_ds))/span
    features = [np.array([float((r['material_id'], r['optical_set_id']) == key) for key in material_keys]
        + [float(normalized[i]), float(centers[i])]) for i, r in enumerate(rows)]
    chosen, identities, result = [], set(), []
    while len(result) < 4:
        remaining = [i for i in range(len(rows)) if i not in chosen]
        if not remaining:
            raise ValueError('fewer than four distinct deletion children')
        def key(i):
            distance = min(float(np.linalg.norm(features[i]-features[j])) for j in chosen) if chosen else float(ds[i])
            return (-distance, rows[i]['id'], i)
        index = min(remaining, key=key)
        chosen.append(index)
        raw = deepcopy(parent)
        raw['front_layers'].pop(index)
        cleaned = cleanup_batch_needle_design(raw, REQUEST.frozen_material_snapshot)
        identity = physical_design_hash(cleaned.design)
        if identity in identities:
            continue
        identities.add(identity)
        result.append(dict(child_id=f'child-{len(result)}', removed_layer_id=rows[index]['id'],
            removed_material_id=rows[index]['material_id'], original_index=index,
            removed_thickness_nm=float(ds[index]), feature=features[index].tolist(),
            raw_layer_count=len(raw['front_layers']), physical_layer_count=len(cleaned.design['front_layers']),
            merged_ids=dict(cleaned.merged_ids), physical_hash=identity, design=cleaned.design))
        if len(result) == 4:
            break
    if len(result) != 4:
        raise ValueError('selection did not yield four unique children')
    return result


def arm(name, parent, children, *, lookahead):
    broker = Broker(name, ARM_CALLS)
    details, raw, endpoints = [], [], []
    chosen = None
    try:
        broker.stage = 'shared_parent_forward_refresh'
        broker.evaluate(parent)
        for child in children:
            broker.stage = child['child_id'] + '_raw'
            raw.append(compact(broker.evaluate(child['design'])))
        raw_order = sorted(range(4), key=lambda i: (describe(raw[i])['weighted_sse'], children[i]['child_id']))
        if lookahead:
            for i in range(4):
                endpoint, detail = broker.refine(raw[i], CHILD_QUOTA, children[i]['child_id'] + '_initial_refit')
                endpoints.append(endpoint)
                details.append(detail)
            chosen = min(range(4), key=lambda i: (describe(endpoints[i])['weighted_sse'], children[i]['child_id']))
            seed = endpoints[chosen]
        else:
            chosen, seed = raw_order[0], raw[raw_order[0]]
        endpoint, detail = broker.refine(seed, ARM_CALLS-broker.calls, children[chosen]['child_id'] + '_remaining_refit')
        details.append(detail)
    except (SynthesisStageBudget, _StructureCancelled):
        endpoint = broker.accepted or broker.champion
    result = dict(**broker.summary(), lookahead=lookahead, chosen_child=chosen,
        raw_order=sorted(range(len(raw)), key=lambda i: (describe(raw[i])['weighted_sse'], children[i]['child_id'])),
        raw_metrics=[describe(x) for x in raw], initial_refit_metrics=[describe(x) for x in endpoints],
        refinement=details, final_exploration_endpoint=None if endpoint is None else describe(endpoint))
    if broker.champion is not None:
        write(name + '-champion.json', dict(design=broker.champion['design'], metrics=describe(broker.champion)))
    if broker.best_sse is not None:
        write(name + '-best-explored.json', dict(design=broker.best_sse['design'], metrics=describe(broker.best_sse)))
    write(name + '-summary.json', result)
    return result


source = json.loads((INPUT/'requested-current-derived-k0-both-enabled.json').read_text())
# Deliberate experimental re-authoring, not a production legacy decoder.
source['schema_version'] = SCHEMA_VERSION
source['request']['enable_thickness_reduction'] = False
source['request_id'] = 'current-target-deletion-lookahead-pilot-v3'
_, REQUEST, _ = film_synthesis_request_from_payload(source)
POINTS = sum(o.wavelength_samples*len(o.angles_deg) for o in REQUEST.objectives)
write('request-v3.json', source)
original_parent = json.loads((INPUT/'pilot-parent62-derived-k0.json').read_text())['design']
write('protocol.json', dict(warm_calls=WARM_CALLS, arm_calls=ARM_CALLS, children=4,
    child_initial_refit_calls=CHILD_QUOTA, wall_seconds=WALL_SECONDS, training_points=POINTS,
    selection='first thickest physical layer, then Euclidean maximin(one-hot exact material/optical-set, normalized log thickness, normalized physical stack center); stable layer ID then original index tie-break',
    cleanup='same exact-zero/same-optical-reference cleanup after shared warm-up and each deletion in both arms',
    score='unchanged canonical weighted_sse_loss_gradient and original scoring; no tolerance relaxation',
    lossless_hypothesis='explicitly derived k=0 for all source datasets; original n/grid unchanged; no engineering material claim',
    scope='screening branch-selection experiment, no denser independent audit or global/local optimum claim',
    source_request_sha256=hashlib.sha256((INPUT/'requested-current-derived-k0-both-enabled.json').read_bytes()).hexdigest(),
    source_parent_sha256=hashlib.sha256((INPUT/'pilot-parent62-derived-k0.json').read_bytes()).hexdigest()))
print('shared warm-up starting', flush=True)
warm = Broker('shared-warmup', WARM_CALLS)
warm.stage = 'initial_parent'
initial = warm.evaluate(original_parent, jacobian=True)
warmed, warm_details = warm.refine(initial, WARM_CALLS-warm.calls, 'shared_parent_refit')
cleaned = cleanup_batch_needle_design(warmed['design'], REQUEST.frozen_material_snapshot)
parent = cleaned.design
warm_summary = warm.summary()
write('shared-parent.json', dict(design=parent, pre_cleanup_metrics=describe(warmed),
    raw_layer_count=len(warmed['design']['front_layers']), physical_layer_count=len(parent['front_layers']),
    merged_ids=dict(cleaned.merged_ids), removed_exact_zero_ids=list(cleaned.removed_exact_zero_ids),
    warmup=warm_summary, warmup_refinement=warm_details))
children = deletion_children(parent)
write('deletion-children.json', children)
print('arm A starting', flush=True)
a = arm('arm-a-raw-choice', parent, children, lookahead=False)
print('arm B starting', flush=True)
b = arm('arm-b-refit-choice', parent, children, lookahead=True)
write('result.json', dict(warmup=warm_summary, warmup_refinement=warm_details,
    parent_raw_layers=len(warmed['design']['front_layers']), parent_physical_layers=len(parent['front_layers']),
    arms=[a,b], no_independent_audit=True,
    inference='Branch-selection pilot only. A finite shared warm-up does not establish a stationary parent.'))
print(json.dumps(dict(done=True, A=a['strict_champion'], B=b['strict_champion']), allow_nan=False), flush=True)

"""Postprocess recorded evaluations only; never dispatch optical physics."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform

import numpy
import scipy

from coat_sim.core.film_synthesis_batch_needle import cleanup_batch_needle_design
from coat_sim.core.film_synthesis_io import film_synthesis_request_from_payload

HERE = Path(__file__).resolve().parent


def read(name):
    return json.loads((HERE / name).read_text())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def rank(metrics):
    if metrics['nominal_pass']:
        return (0, metrics['layer_count'], metrics['total_thickness_nm'],
                metrics['max_error'], metrics['weighted_sse'])
    return (1, metrics['max_error'], metrics['weighted_sse'],
            metrics['layer_count'], metrics['total_thickness_nm'])


def prefix(trace, count):
    records = [r for r in trace if r['complete']][:count]
    strict = min(records, key=lambda r: rank(r['metrics']))
    sse = min(records, key=lambda r: r['metrics']['weighted_sse'])
    last = records[-1]
    return dict(completed_calls=len(records),
                forward_calls=sum(not r['jacobian'] for r in records),
                jacobian_calls=sum(r['jacobian'] for r in records),
                elapsed_at_last_completed_call_seconds=last['elapsed_seconds'],
                forward_point_layers=last['cumulative_forward_point_layers'],
                jacobian_point_layers=last['cumulative_jacobian_point_layers'],
                total_point_layers=last['cumulative_forward_point_layers'] +
                                   last['cumulative_jacobian_point_layers'],
                strict_champion_call=strict['call'], strict_champion=strict['metrics'],
                best_sse_call=sse['call'], best_explored_sse=sse['metrics'])


_, request, _ = film_synthesis_request_from_payload(read('request-v3.json'))
result = read('result.json')
traces = [[json.loads(row) for row in (HERE / (arm['name'] + '-calls.jsonl')).read_text().splitlines()]
          for arm in result['arms']]
assert all(r['complete'] for trace in traces for r in trace)
assert result['arms'][0]['raw_metrics'] == result['arms'][1]['raw_metrics']
count = min(arm['completed_calls'] for arm in result['arms'])
matched = [prefix(trace, count) for trace in traces]
conservative_a_count = max(i for i in range(1, count + 1)
                          if prefix(traces[0], i)['total_point_layers'] <= matched[1]['total_point_layers'])
cleanup = {}
for arm in result['arms']:
    for role in ('champion', 'best-explored'):
        stored = read(arm['name'] + '-' + role + '.json')
        cleaned = cleanup_batch_needle_design(stored['design'], request.frozen_material_snapshot)
        assert cleaned.algebraically_equivalent and not cleaned.requires_full_reevaluation
        cleanup[arm['name'] + '-' + role] = dict(
            raw_layer_count=len(stored['design']['front_layers']),
            physical_layer_count=len(cleaned.design['front_layers']),
            removed_exact_zero_ids=list(cleaned.removed_exact_zero_ids),
            merged_ids=dict(cleaned.merged_ids),
            algebraic_only_no_optical_dispatch=True)
comparison = dict(
    conclusion='Negative for this fixed schedule and parent: no winning-branch reversal; baseline has lower original max violation and SSE at both matched-call and conservative lower-work prefixes. It is thicker, so this is not blanket Pareto dominance.',
    production_commit='7e43ebf845d82e50e7bf38bbcc227671fbc68b04',
    environment=dict(python=platform.python_version(), numpy=numpy.__version__, scipy=scipy.__version__,
                     requested_threads=1),
    actual_arm_summaries=[{k: v for k, v in arm.items()
                          if k not in ('refinement', 'raw_metrics', 'initial_refit_metrics')}
                         for arm in result['arms']],
    matched_completed_call_count=count,
    matched_completed_call_prefixes=matched,
    conservative_work_comparison=dict(
        rationale='A largest completed prefix with no greater total point-layer proxy than B43; F and FJ work separately retained, not wall-time or FLOP equivalence.',
        A=prefix(traces[0], conservative_a_count), B=matched[1]),
    raw_sse_order=result['arms'][0]['raw_order'],
    after_8_call_refit_sse_order=sorted(range(4), key=lambda i: (
        result['arms'][1]['initial_refit_metrics'][i]['weighted_sse'], i)),
    final_layer_cleanup=cleanup,
    limitations=[
        'One fresh deterministic explicitly derived k=0 parent; not an engineering material dataset or recovered historical design.',
        'Both mean and pointwise enabled only; no held-out or independent mode ablations in this pilot.',
        'Coarse <=5 nm by 1 degree screening grid only; no independent dense/extremum audit.',
        'Shared 24-call warm-up remained descending, so not evidence of a stationary local minimum or escape.',
        'Both arms ended at the fixed cooperative 90 s admission deadline before 64 calls; bookkeeping can return after deadline.',
        'Single serial order A then B, no timing repeat; point-layer work is a proxy, not an exact operation or memory measure.',
        'B restarts the chosen local refiner after initial competition; optimizer-state continuity is not isolated from branch-budget dilution.',
        'No changed optical targets, hidden margins, manufacturing limits, scorer optimization, or default-production lookahead change.',
    ])
write('compact-comparison.json', comparison)
write('artifact-manifest.json', dict(
    production_commit=comparison['production_commit'],
    runtime=comparison['environment'],
    command='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONPATH=<source-checkout-at-recorded-sha> <python-with-recorded-dependencies> run_pilot.py',
    harness_note='run_pilot.py has a relative inputs/ binding for portability. The only post-run change and both hashes are recorded in portable-harness-provenance.json. Re-running overwrites outputs, so use a separate copy.',
    files={str(path.relative_to(HERE)): hashlib.sha256(path.read_bytes()).hexdigest()
           for path in sorted(HERE.rglob('*')) if path.is_file() and '__pycache__' not in path.parts
           and path.name != 'artifact-manifest.json'}))
print(json.dumps(dict(matched_calls=count, conservative_a_calls=conservative_a_count,
                     final_layer_cleanup=cleanup), indent=2))

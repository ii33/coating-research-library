"""Research-only proposal hints. Never rewrite scoring or audit objectives.

A T ceiling suggests a reflective starting structure, not R=1-T in an
absorbing stack. All actual optimization and acceptance retains original T.
"""
from dataclasses import replace
from functools import wraps

from coat_sim.core.film_objective_criteria import FilmObjectiveConstraint


def proposal_request(request):
    objectives = []
    hints = []
    for index, objective in enumerate(request.objectives):
        bound = objective.pointwise
        if (objective.metric == 'T' and objective.weight > 0 and bound.enabled
                and bound.mode == 'range' and bound.upper_bound is not None
                and 0 <= bound.upper_bound <= .5
                and (bound.lower_bound is None or bound.lower_bound <= 0)):
            objectives.append(replace(objective, metric='R',
                pointwise=FilmObjectiveConstraint(lower_bound=1-bound.upper_bound,
                    upper_bound=None, strict_lower=bound.strict_upper),
                mean=FilmObjectiveConstraint(enabled=False)))
            hints.append(dict(objective_index=index, original_metric='T',
                original_upper=bound.upper_bound, proposal_R_floor=1-bound.upper_bound,
                acceptance_equivalence=False))
        else:
            objectives.append(objective)
    return replace(request, objectives=tuple(objectives)), hints


def install():
    from coat_sim.core import film_synthesis_global as global_priors
    from coat_sim.core import film_synthesis_multispectral_priors as multi
    from coat_sim.core import film_synthesis_hr_priors as dual

    def wrap(original):
        @wraps(original)
        def generate(request, **kwargs):
            hinted, hints = proposal_request(request)
            for proposal in original(hinted, **kwargs):
                yield replace(proposal, provenance=dict(proposal.provenance,
                    research_transmission_stopband_hints=hints))
        return generate

    for module, name in ((global_priors, 'iter_reflector_proposals'),
                         (global_priors, 'iter_bandpass_proposals'),
                         (multi, 'iter_multispectral_hr_proposals'),
                         (dual, 'iter_dual_substack_hr_proposals')):
        setattr(module, name, wrap(getattr(module, name)))
    prior = global_priors.iter_reflector_proposals

    def with_narrow(request, **kwargs):
        yield from narrow_proposals(request, **kwargs)
        yield from prior(request, **kwargs)
    global_priors.iter_reflector_proposals = with_narrow


def narrow_proposals(request, *, cancel_check=lambda: None, **_kwargs):
    """Experimental normal-incidence binary duty-cycle stacks, not a bound.

    Cell Bloch attenuation at half-wave phase sets a heuristic period count.
    Nearest pass windows guide bandwidth; full complex optics remains in parent.
    """
    import math
    from copy import deepcopy
    from itertools import combinations, product
    from coat_sim.core.film_synthesis_global import StructuralProposal
    from coat_sim.core.optical_constants import prepare_optical_set
    from coat_sim.core.film_synthesis_absorption import sample_synthesis_optical, assumes_unknown_k_zero
    if (request.seed_designs or request.environment['front_layers']
            or request.environment['back_layers']
            or request.environment['substrate']['sides'] != 'single'
            or any(o.angles_deg != (0.0,) for o in request.objectives)):
        return
    stops = [o for o in request.objectives if o.metric == 'T' and o.weight > 0
             and o.pointwise.enabled and o.pointwise.mode == 'range'
             and o.pointwise.upper_bound is not None and 0 < o.pointwise.upper_bound < .5]
    passes = [o for o in request.objectives if o.metric == 'T' and o.weight > 0
              and o.pointwise.enabled and o.pointwise.mode == 'range'
              and o.pointwise.lower_bound is not None and o.pointwise.lower_bound > .5]
    if not stops or not passes:
        return
    materials = {m['id']:m for m in request.frozen_material_snapshot['materials']}
    refs = [(r.material_id,r.optical_set_id) for r in request.candidate_materials]
    samplers = {r:prepare_optical_set(next(o for o in materials[r[0]]['optical_sets'] if o['id']==r[1]), k_sampling_policy='source') for r in refs}
    serial = 0
    for pair in combinations(refs,2):
        specs=[]
        for stop in stops:
            c=math.sqrt(stop.wavelength_min_nm*stop.wavelength_max_nm)
            ns={r:sample_synthesis_optical(samplers[r],c,assume_unknown_k_zero=assumes_unknown_k_zero(request))[0] for r in pair}
            hi,lo=sorted(pair,key=lambda r:ns[r],reverse=True)
            ratio=ns[hi]/ns[lo]
            if ratio<=1:
                break
            eta=(ratio+1/ratio)/2
            left=[p.wavelength_max_nm for p in passes if p.wavelength_max_nm<stop.wavelength_min_nm]
            right=[p.wavelength_min_nm for p in passes if p.wavelength_min_nm>stop.wavelength_max_nm]
            duty=.5
            if left and right:
                a=(max(left)+stop.wavelength_min_nm)/2
                b=(min(right)+stop.wavelength_max_nm)/2
                kappa=math.pi*(b-a)/c/2
                duty=math.asin(math.sqrt(min(1.,(math.cosh(kappa)-1)/(eta-1))))/math.pi
            specs.append((stop,c,ns,hi,lo,eta,duty))
        if len(specs)!=len(stops):
            continue
        for duty_factor,count_factor,reverse in product((1.,.85,1.15),(1.,1.5),(False,True)):
            cancel_check();rows=[];metadata=[]
            for stop,c,ns,hi,lo,eta,duty in (reversed(specs) if reverse else specs):
                f=min(.5,duty*duty_factor) if duty<.5 else duty
                attenuation=math.acosh(1+(eta-1)*math.sin(math.pi*f)**2)
                # Interior reflectivity is only a seed construction convention.
                target=1-stop.pointwise.upper_bound*.1
                count=math.ceil(count_factor*math.atanh(math.sqrt(target))/attenuation)
                metadata.append(dict(center_nm=c,high_phase_fraction=f,pairs=count))
                for _ in range(count):
                    for ref,frac in ((hi,f),(lo,1-f)):
                        rows.append(dict(id=f'narrow-{serial}-{len(rows)}',material_id=ref[0],optical_set_id=ref[1],thickness=dict(value=c*frac/(2*ns[ref]),unit='nm'),note='Experimental target-derived duty-cycle seed'))
            serial+=1
            design=deepcopy(request.environment);design['front_layers']=list(reversed(rows))
            yield StructuralProposal(design,dict(family='experimental_narrow_duty',windows=metadata,search_convention=True,acceptance_equivalence=False))

#!/usr/bin/env python3
"""Reference TiO2/SiO2/H-K9L diagnostic, NOT the user's frozen settings.

`preflight` only builds/freezes/validates the GUI-equivalent typed request.
`run` is an explicit separate action: it executes the saved spec, with a
120-second cooperative cancellation and an independent 512-evaluation cap.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sys
import subprocess
import threading
import time
import traceback

# Limit numerical thread pools before importing numpy/scipy or project modules.
THREAD_ENV = {name: "1" for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS", "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")}
os.environ.update(THREAD_ENV)
if hasattr(os, 'sched_getaffinity') and hasattr(os, 'sched_setaffinity'):
    allowed_cpus = sorted(os.sched_getaffinity(0))
    if not allowed_cpus:
        raise RuntimeError('no allowed CPU for this diagnostic')
    os.sched_setaffinity(0, {allowed_cpus[0]})
    AFFINITY = {'enforced': True, 'logical_cpus': sorted(os.sched_getaffinity(0))}
else:
    AFFINITY = {'enforced': False, 'reason': 'OS affinity API unavailable; cpu_workers and numerical threads still set to 1'}
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from coat_sim.core.film_auto_synthesis import freeze_film_synthesis_request  # noqa: E402
from coat_sim.core.film_design import new_design  # noqa: E402
from coat_sim.core.film_nominal_acceptance import nominal_condition_pass  # noqa: E402
from coat_sim.core.film_objective_criteria import FilmObjectiveConstraint  # noqa: E402
from coat_sim.core.film_optimization import FilmOptimizationObjective, FilmOptimizationRequest  # noqa: E402
from coat_sim.core.film_optimization_needle import FilmNeedleMaterialReference  # noqa: E402
from coat_sim.core.film_synthesis_jobs import deserialize_job_payload, execute_job, is_synthesis_result  # noqa: E402
from coat_sim.scheduler.jobs import JobSpec  # noqa: E402
from coat_sim.ui.film_synthesis_quick_adapter import build_synthesis_request, synthesis_spec  # noqa: E402
from tools.run_film_synthesis_acceptance import AcceptanceService, atomic_json, jsonable  # noqa: E402

INPUT = HERE / 'reference-input.json'
CATALOG = ROOT / 'data/optical_catalog.json'
SUBSTRATES = ROOT / 'coat_sim/core/resources/optical_substrate_supplement.json'


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_reference():
    config = read_json(INPUT)
    catalog = read_json(CATALOG)
    supplement = read_json(SUBSTRATES)
    rows = []
    selections = []
    for ref in config['film_materials']:
        material = next(row for row in catalog['materials']
                        if row['builtin_material_id'] == ref['material_id'])
        selected = next(group for group in material['optical_constants']
                        if group['id'] == ref['optical_set_id'])
        rows.append(dict(id=ref['material_id'], name=material['material_id'],
                         design_ready=True, optical_sets=deepcopy(material['optical_constants'])))
        selections.append(dict(role='film', material_id=ref['material_id'],
                               optical_set_id=ref['optical_set_id'], optical=deepcopy(selected)))
    substrate = config['substrate']
    substrate_row = next(row for row in supplement['materials'] if row['id'] == substrate['material_id'])
    substrate_set = next(row for row in substrate_row['optical_sets'] if row['id'] == substrate['optical_set_id'])
    rows.append(deepcopy(substrate_row))
    selections.append(dict(role='substrate', material_id=substrate['material_id'],
                           optical_set_id=substrate['optical_set_id'], optical=deepcopy(substrate_set)))
    service = AcceptanceService(rows)
    design = new_design(name='参考双阻带诊断（非用户原参）', design_id='reference-dual-stopband-20261101')
    design['substrate'].update(substrate)
    windows = config['windows']
    objectives = []
    for row in windows:
        low, high = row['low_nm'], row['high_nm']
        samples = int(round((high - low) / config['sample_spacing_nm'])) + 1
        assert samples >= 2 and (high - low) / (samples - 1) == config['sample_spacing_nm']
        constraint = (FilmObjectiveConstraint(lower_bound=row['bound'], upper_bound=None, strict_lower=True)
                      if row['relation'] == '>' else
                      FilmObjectiveConstraint(lower_bound=None, upper_bound=row['bound'], strict_upper=True))
        objectives.append(FilmOptimizationObjective(low, high, samples, angles_deg=(config['angle_deg'],),
            polarization=config['polarization'], metric='T', pointwise=constraint,
            weight=1., normalization_scale=1.))
    base = FilmOptimizationRequest(design, 0, (), tuple(objectives),
        acceptable_normalized_error=config['acceptable_normalized_error'],
        validation_samples_multiplier=config['validation_samples_multiplier'])
    references = tuple(FilmNeedleMaterialReference(**row) for row in config['film_materials'])
    options = {**config['options'], 'structure_search_seed': config['seed'],
               'randomize_template_search': False}
    request = build_synthesis_request(base, references, options, use_current_seed=False,
        assume_unknown_k_zero=config['assume_unknown_k_zero'], cpu_workers=config['cpu_workers'],
        forward_backend='cpu')
    frozen = freeze_film_synthesis_request(service, request)
    assert frozen.search_strategy == 'hybrid' and frozen.search_until_target is False
    assert frozen.structure_search_seed == config['seed'] and frozen.max_evaluations == 512
    assert frozen.max_cycles is None and frozen.max_seconds is None
    assert frozen.max_layers is None and frozen.max_total_thickness_nm is None
    assert frozen.max_layer_thickness_nm is None and frozen.minimum_nonzero_thickness_nm is None
    assert frozen.max_working_set_bytes is None and frozen.cpu_workers == 1
    assert frozen.environment['substrate']['sides'] == 'single'
    assert frozen.environment['substrate']['mode'] == 'auto'
    assert frozen.environment['substrate']['thickness'] == {'value': 1.0, 'unit': 'mm'}
    assert [o.wavelength_samples for o in frozen.objectives] == [101, 41, 141, 41]
    assert frozen.environment['assume_lossless'] is True and frozen.environment['use_k'] is True
    spec = synthesis_spec(service, frozen)
    parsed = JobSpec.parse_frozen(spec)
    _, decoded, structures = deserialize_job_payload(parsed.parameters['payload'])
    assert decoded == frozen and not structures
    return config, frozen, spec, parsed, selections


def preflight(output: Path):
    config, frozen, spec, parsed, selections = build_reference()
    output.mkdir(parents=True, exist_ok=False)
    atomic_json(output / 'input.json', config)
    atomic_json(output / 'request.json', asdict(frozen))
    atomic_json(output / 'job-spec.json', spec)
    atomic_json(output / 'sources.json', {
        'scope': 'repository reference data only; not verified user input',
        'input_sha256': digest(INPUT), 'runner_sha256': digest(Path(__file__)),
        'source_commit': subprocess.run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'],
            check=True, capture_output=True, text=True).stdout.strip(),
        'catalog_sha256': digest(CATALOG),
        'substrate_supplement_sha256': digest(SUBSTRATES),
        'job_fingerprint': parsed.fingerprint, 'materials': selections,
        'samples_per_window': [o.wavelength_samples for o in frozen.objectives],
        'no_synthesis_executed': True, 'thread_environment': THREAD_ENV, 'cpu_affinity': AFFINITY,
    })
    print(f'preflight only: {output}; four windows [101, 41, 141, 41]; no synthesis executed')


def window_facts(score, objectives, *, audit_available):
    if not isinstance(score, dict) or not isinstance(score.get('errors'), list):
        return [dict(objective_index=i, available=False, reason='no complete saved score')
                for i in range(len(objectives))]
    result = []
    for i, objective in enumerate(objectives):
        rows = [row for row in score['errors'] if row.get('objective_index') == i
                and row.get('reduction') == 'pointwise']
        actuals = [row['actual'] for row in rows]
        violating = [row for row in rows if not nominal_condition_pass(objective.pointwise, row['actual'])]
        worst = max(rows, key=lambda row: (row['normalized_violation'],
            not nominal_condition_pass(objective.pointwise, row['actual']))) if rows else None
        result.append(dict(objective_index=i, available=bool(rows), observed_rows=len(rows),
            audit_available=audit_available, min_T=min(actuals) if actuals else None,
            max_T=max(actuals) if actuals else None, observed_violations=len(violating),
            worst_wavelength_nm=worst.get('wavelength_nm') if worst else None,
            worst_actual_T=worst.get('actual') if worst else None,
            worst_normalized_violation=worst.get('normalized_violation') if worst else None,
            note='观测值，不是连续谱证明；未完成独审时不冒充审计通过'))
    return result


def run(preflight_dir: Path, output: Path, variant: str):
    config = read_json(preflight_dir / 'input.json')
    spec = JobSpec.parse_frozen(read_json(preflight_dir / 'job-spec.json'))
    _, request, _ = deserialize_job_payload(spec.parameters['payload'])
    recorded = read_json(preflight_dir / 'sources.json')
    if spec.fingerprint != recorded['job_fingerprint']:
        raise ValueError('preflight job identity mismatch')
    if config != read_json(INPUT):
        raise ValueError('input differs from the preflight reference input')
    if recorded.get('runner_sha256') != digest(Path(__file__)):
        raise ValueError('runner differs from preflight; create a new preflight')
    experiment_path = HERE / 'proposal_hints_experiment.py'
    if variant == 'stopband-hints':
        if not experiment_path.is_file():
            raise FileNotFoundError('proposal_hints_experiment.py is not available')
        import proposal_hints_experiment
        proposal_hints_experiment.install()
    experiment_hash = digest(experiment_path) if variant == 'stopband-hints' else None
    output.mkdir(parents=True, exist_ok=False)
    atomic_json(output / 'run-input.json', config)
    atomic_json(output / 'source-binding.json', {**recorded, 'variant': variant,
        'experiment_sha256': experiment_hash, 'thread_environment': THREAD_ENV, 'cpu_affinity': AFFINITY})
    cancel = threading.Event()
    deadline_hit = threading.Event()
    def deadline():
        deadline_hit.set()
        cancel.set()
    timer = threading.Timer(config['diagnostic_wall_seconds'], deadline)
    lock = threading.Lock()
    started = time.monotonic()
    def report(value, **_kwargs):
        with lock, (output / 'progress.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({'elapsed_seconds': time.monotonic() - started,
                                     'progress': jsonable(value)}, ensure_ascii=False, allow_nan=False) + '\n')
    timer.start()
    try:
        response = execute_job(spec.parameters, cancel, report, output / 'best-candidate.json',
                               atomic_json, str(output.resolve()))
        elapsed = time.monotonic() - started
        if not is_synthesis_result(response):
            raise ValueError('worker returned invalid synthesis result')
        body = response['result']
        audit = response.get('best_candidate_audit') or {}
        performance = body.get('performance') or {}
        archive = (performance.get('search') or {}).get('design_archive') or {}
        from coat_sim.core.film_synthesis_archive import physical_design_hash
        candidate = body.get('candidate_design')
        candidate_hash = physical_design_hash(candidate) if candidate is not None else None
        matched = [entry for entry in archive.get('entries', []) if entry.get('physical_hash') == candidate_hash]
        summary = dict(kind='reference_diagnostic_not_user_actual_configuration', variant=variant,
            experiment_sha256=experiment_hash, elapsed_seconds=elapsed,
            wall_limit_seconds=config['diagnostic_wall_seconds'], wall_cancel_requested=deadline_hit.is_set(),
            state=body.get('state'), termination_reason=body.get('termination_reason'),
            targets_met=body.get('targets_met'), validation_complete=body.get('validation_complete'),
            counters={name: body.get(name) for name in ('cycles', 'evaluations', 'validation_evaluations',
                'failed_evaluations', 'audit_physical_evaluations', 'audit_wavelength_points')},
            training_windows=window_facts(body.get('training_score'), request.objectives, audit_available=False),
            audit_windows=window_facts(body.get('validation_score'), request.objectives,
                                       audit_available=audit.get('available') is True),
            review_per_objective=response.get('review', {}).get('per_objective', []),
            candidate_provenance=body.get('candidate_provenance'),
            candidate_structure_sources=[{'operator': e.get('operator'), 'provenance': e.get('provenance')}
                                         for e in matched],
            structure_source_note='空列表表示归档没有匹配项，不推断结构来源。',
            performance_search=performance.get('search'), cleanup_complete=performance.get('cleanup_complete'))
        atomic_json(output / 'result.json', response)
        atomic_json(output / 'summary.json', summary)
        print(json.dumps({k: summary[k] for k in ('state', 'termination_reason', 'targets_met',
            'elapsed_seconds', 'counters', 'training_windows', 'audit_windows')}, ensure_ascii=False, indent=2))
    except Exception as exc:
        atomic_json(output / 'failure.json', {'type': type(exc).__name__, 'message': str(exc),
            'traceback': traceback.format_exc(), 'elapsed_seconds': time.monotonic() - started})
        raise
    finally:
        timer.cancel()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    pre = commands.add_parser('preflight')
    pre.add_argument('--output', type=Path, default=HERE / 'preflight')
    execute = commands.add_parser('run')
    execute.add_argument('--preflight', type=Path, default=HERE / 'preflight')
    execute.add_argument('--output', type=Path, required=True, help='new, nonexistent directory')
    execute.add_argument('--variant', required=True, choices=('baseline', 'stopband-hints'))
    args = parser.parse_args()
    if args.command == 'preflight':
        preflight(args.output)
    else:
        run(args.preflight, args.output, args.variant)


if __name__ == '__main__':
    main()

"""Research-only proposal hints. Never rewrite scoring or audit objectives.

A T ceiling suggests a reflective starting structure, not R=1-T in an
absorbing stack. All actual optimization and acceptance retains original T.
"""
from dataclasses import replace
from functools import wraps

from coat_sim.core.film_objective_criteria import FilmObjectiveConstraint


def proposal_request(request):
    objectives = []
    hints = []
    for index, objective in enumerate(request.objectives):
        bound = objective.pointwise
        if (objective.metric == 'T' and objective.weight > 0 and bound.enabled
                and bound.mode == 'range' and bound.upper_bound is not None
                and 0 <= bound.upper_bound <= .5
                and (bound.lower_bound is None or bound.lower_bound <= 0)):
            objectives.append(replace(objective, metric='R',
                pointwise=FilmObjectiveConstraint(lower_bound=1-bound.upper_bound,
                    upper_bound=None, strict_lower=bound.strict_upper),
                mean=FilmObjectiveConstraint(enabled=False)))
            hints.append(dict(objective_index=index, original_metric='T',
                original_upper=bound.upper_bound, proposal_R_floor=1-bound.upper_bound,
                acceptance_equivalence=False))
        else:
            objectives.append(objective)
    return replace(request, objectives=tuple(objectives)), hints


def install():
    from coat_sim.core import film_synthesis_global as global_priors
    from coat_sim.core import film_synthesis_multispectral_priors as multi
    from coat_sim.core import film_synthesis_hr_priors as dual

    def wrap(original):
        @wraps(original)
        def generate(request, **kwargs):
            hinted, hints = proposal_request(request)
            for proposal in original(hinted, **kwargs):
                yield replace(proposal, provenance=dict(proposal.provenance,
                    research_transmission_stopband_hints=hints))
        return generate

    for module, name in ((global_priors, 'iter_reflector_proposals'),
                         (global_priors, 'iter_bandpass_proposals'),
                         (multi, 'iter_multispectral_hr_proposals'),
                         (dual, 'iter_dual_substack_hr_proposals')):
        setattr(module, name, wrap(getattr(module, name)))

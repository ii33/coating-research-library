#!/usr/bin/env python3
"""Summarize an already saved typed result; never runs optical calculations."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from coat_sim.core.film_nominal_acceptance import nominal_condition_pass  # noqa: E402
from coat_sim.core.film_objective_payload import objective_from_payload  # noqa: E402
from coat_sim.core.film_synthesis_archive import physical_design_hash  # noqa: E402
from coat_sim.core.film_synthesis_jobs import is_synthesis_result  # noqa: E402


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def window_summary(score, objectives, *, scope, available):
    result = []
    for index, objective in enumerate(objectives):
        base = dict(objective_index=index, window_nm=[objective.wavelength_min_nm, objective.wavelength_max_nm],
            metric=objective.metric, lower_bound=objective.pointwise.lower_bound,
            upper_bound=objective.pointwise.upper_bound, strict_lower=objective.pointwise.strict_lower,
            strict_upper=objective.pointwise.strict_upper, scope=scope, available=available)
        if not available or not isinstance(score, dict) or not isinstance(score.get('errors'), list):
            result.append({**base, 'available': False, 'reason': 'no complete matching ' + scope + ' evidence',
                           'min_T': None, 'max_T': None, 'strict_violations': None})
            continue
        rows = [row for row in score['errors'] if isinstance(row, dict)
                and row.get('objective_index') == index and row.get('reduction') == 'pointwise']
        if not rows:
            result.append({**base, 'available': False, 'reason': 'no pointwise rows',
                           'min_T': None, 'max_T': None, 'strict_violations': None})
            continue
        if any(type(row.get('actual')) not in (float, int) or not math.isfinite(row['actual']) for row in rows):
            raise ValueError(f'non-finite response in objective {index}')
        violations = [row for row in rows if not nominal_condition_pass(objective.pointwise, row['actual'])]
        minimum = min(rows, key=lambda row: row['actual'])
        maximum = max(rows, key=lambda row: row['actual'])
        result.append({**base, 'sampled_pointwise_rows': len(rows),
            'min_T': minimum['actual'], 'min_wavelength_nm': minimum['wavelength_nm'],
            'max_T': maximum['actual'], 'max_wavelength_nm': maximum['wavelength_nm'],
            'strict_violations': len(violations), 'all_observed_points_pass': not violations,
            'max_normalized_violation': max(row['normalized_violation'] for row in rows),
            'interpretation': '仅保存的采样证据；严格等于边界也算违例，不是连续谱证明。'})
    return result


def postprocess(result_path: Path, output_path: Path):
    payload = read_json(result_path)
    if not is_synthesis_result(payload):
        raise ValueError('saved result failed the production typed-result validator')
    body = payload['result']
    frozen = body['frozen_request']
    objectives = tuple(objective_from_payload(row) for row in frozen['objectives'])
    if len(objectives) != 4 or any(row.metric != 'T' or not row.pointwise.enabled for row in objectives):
        raise ValueError('expected four pointwise T objectives in frozen request')
    candidate = body.get('candidate_design')
    if not isinstance(candidate, dict):
        raise ValueError('no retained candidate design; cannot report a selected structure')
    candidate_hash = physical_design_hash(candidate)
    training = body.get('training_score')
    validation = body.get('validation_score')
    training_matches = (isinstance(training, dict) and isinstance(training.get('design'), dict)
                        and physical_design_hash(training['design']) == candidate_hash)
    review = payload.get('review') or {}
    review_rows = review.get('per_objective') or []
    review_has_audit = (len(review_rows) == len(objectives)
                        and all(row.get('score_scope') != 'training' for row in review_rows))
    audit_matches = (body.get('validation_complete') is True and isinstance(validation, dict)
                     and isinstance(validation.get('design'), dict)
                     and physical_design_hash(validation['design']) == candidate_hash
                     and isinstance(validation.get('audit'), dict) and review_has_audit)
    if not training_matches:
        raise ValueError('training score does not match selected physical candidate')
    selected_surfaces = review.get('selected_surfaces')
    if (not isinstance(selected_surfaces, list) or not selected_surfaces
            or any(side not in ('front', 'back') for side in selected_surfaces)):
        raise ValueError('missing or invalid selected synthesis surfaces')
    selected = []
    for side in selected_surfaces:
        for row in candidate.get(side + '_layers', []):
            thickness = row.get('thickness') or {}
            if thickness.get('unit') != 'nm':
                raise ValueError('selected layer thickness is not in nm')
            selected.append(dict(side=side, material_id=row.get('material_id'),
                optical_set_id=row.get('optical_set_id'), thickness_nm=thickness.get('value')))
    archive = (body.get('performance', {}).get('search', {}).get('design_archive') or {})
    matching = [entry for entry in archive.get('entries', [])
                if entry.get('physical_hash') == candidate_hash]
    sources = [dict(operator=row.get('operator'), provenance=row.get('provenance'),
                    parent_hash=row.get('parent_hash')) for row in matching]
    run_summary = result_path.with_name('summary.json')
    saved_run = read_json(run_summary) if run_summary.is_file() else {}
    out = dict(kind='reference_diagnostic_corrected_window_summary',
        source_result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest(),
        scope='项目内参考材料/参数，非用户实际配置；有限采样不是连续谱证书。',
        state=body.get('state'), termination_reason=body.get('termination_reason'),
        targets_met=body.get('targets_met'), validation_complete=body.get('validation_complete'),
        training_candidate_matches=training_matches, audit_candidate_matches=audit_matches,
        audit_evidence_basis='validation_complete + matching validation_score.audit + non-training review; typed-result validated',
        elapsed_seconds=saved_run.get('elapsed_seconds'),
        work_counters={key: body.get(key) for key in ('cycles', 'evaluations', 'validation_evaluations',
            'failed_evaluations', 'audit_physical_evaluations', 'audit_wavelength_points')},
        selected_surfaces=selected_surfaces, selected_layer_count=len(selected),
        total_thickness_nm=sum(row['thickness_nm'] for row in selected),
        selected_layers=selected, candidate_structure_sources=sources,
        structure_source_note='无归档匹配时不推断来源。',
        training_windows=window_summary(training, objectives, scope='training', available=training_matches),
        audit_windows=window_summary(validation, objectives, scope='independent_audit', available=audit_matches),
        review_per_objective=review_rows)
    with output_path.open('x', encoding='utf-8') as stream:
        json.dump(out, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: out[key] for key in ('state', 'termination_reason', 'targets_met',
        'elapsed_seconds', 'work_counters', 'selected_layer_count', 'total_thickness_nm',
        'candidate_structure_sources', 'training_windows', 'audit_windows')}, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result', type=Path, help='existing complete result.json')
    parser.add_argument('--output', type=Path, help='new output path; defaults next to result')
    args = parser.parse_args()
    postprocess(args.result, args.output or args.result.with_name('corrected-window-summary.json'))


if __name__ == '__main__':
    main()
